package com.cingo.logstore.logfile;

import java.util.List;

public interface LogWrapper {

	List<String> getLineContents();
}
