package com.cingo.logstore.job;

public interface Job {
	
	void run() throws JobException;

}
