# logstorageportal
Projeto criado como exemplo de Front-end do Teste de candidados (versão 1.0) a vagas de desenvolvimento Cingo.

# Pré-requisitos para execução
1. Google Chrome (Version 87)

# Executar projeto
1. Acessar o arquivo js\main.js e verificar se o valor da constante "endpoint" existente na linha 1 está de acordo com a realidade de seu servidor.
2. Abrir o arquivo logstore.html no seu navegador Google Chrome.
